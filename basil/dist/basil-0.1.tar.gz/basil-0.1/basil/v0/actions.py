import argparse
from io import to_unicode
from utils import DebugException


class ActionCollectionConfig(object):
    """Configuration management class to manage a collection of available
    actions."""

    def __init__(self):
        # Create parser.
        self.parser = argparse.ArgumentParser(
                description='Build a system instant-like.')
        self.parser.add_argument('-v', '--verbose', action='store_true',
                help='show verbose debug output')
        self.subparsers = self.parser.add_subparsers()

    def add_action(self, name, func, **kwargs):
        """Add an action to this configuration.
        func will be called with a namespace containing the names of
        arguments added to this action. Option dashes will be omitted from the
        names. E.g. '--foo' will be named 'foo'"""
        # Add a subparser for this action.
        action = self.subparsers.add_parser(name, **kwargs)
        # Set the function to be called for this action.
        action.set_defaults(func=func)
        return action

    def execute(self):
        """Parses command line arguments with the configured actions, and
        executes the specified action."""
        args = self.parser.parse_args()
        ex = None
        try:
            args.func(args)
        except DebugException as e:
            e.debug = args.verbose
            ex = e
        except Exception as e:
            ex = e

        if ex != None:
            print('* {}'.format(to_unicode(ex)))
