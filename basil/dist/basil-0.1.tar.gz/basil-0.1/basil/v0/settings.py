from os import getenv
from os.path import join, isfile
from io import to_unicode, EncodedFile
import json

basil_settings_path = join(getenv('HOME'), '.basil-settings')


def read_basil_settings():
    settings = {}

    if isfile(basil_settings_path):
        with EncodedFile(basil_settings_path, 'r') as fp:
            try:
                settings = json.load(fp)
            except:
                pass

    if type(settings) != dict:
        settings = {}

    return settings


def get_basil_setting(key, default=None):
    key = to_unicode(key)

    settings = read_basil_settings()

    return settings.get(key, default)


def set_basil_setting(key, value):
    key = to_unicode(key)

    settings = read_basil_settings()
    settings[key] = value

    with EncodedFile(basil_settings_path, 'w') as fp:
        json.dump(settings, fp, ensure_ascii=False)


def unset_basil_setting(key):
    key = to_unicode(key)

    settings = read_basil_settings()
    settings.pop(key, None)

    with EncodedFile(basil_settings_path, 'w') as fp:
        json.dump(settings, fp, ensure_ascii=False)
