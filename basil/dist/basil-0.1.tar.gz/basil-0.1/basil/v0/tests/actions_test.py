# Run with: basil$ python -m v0.tests.actions_test
import unittest
from .. import actions
import argparse


class TestActionCollectionConfig(unittest.TestCase):

    def setUp(self):
        self.acc = actions.ActionCollectionConfig()

    def test_add_action(self):
        def test_func():
            pass

        action = self.acc.add_action('testing', test_func)
        self.assertIsInstance(action, argparse.ArgumentParser)
        self.assertEqual(action._defaults['func'], test_func)

if __name__ == '__main__':
    unittest.main()
