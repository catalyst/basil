# Run with: basil$ python -m v0.tests.hooks_test
from __future__ import print_function
import unittest
from .. import hooks
import sys
from StringIO import StringIO


def bad_hook(settings):
    raise Exception('bad_hook{}'.format(settings['a']))


def good_hook(settings):
    print('good_hook{}'.format(settings['a']))


class TestHooksModule(unittest.TestCase):

    def test_run_hook(self):
        saved_stdout = sys.stdout
        try:
            settings = {'a': 1}

            test_cases = [
                    (sys.modules[self.__module__], 'good_hook',
                            ('good_hook{}'.format(settings['a']))),
                    (sys.modules[self.__module__], 'bad_hook',
                            ('* bad_hook{}'.format(settings['a']),
                            '* bad_hook-hook failed'.format(settings['a']))),
                    (sys.modules[self.__module__], 'unknown_hook',
                            ('* unknown_hook() function not found in module'))
                    ]

            for test_case in test_cases:
                sys.stdout = StringIO()
                try:
                    hooks.run_hook(hook_module=test_case[0], hook=test_case[1],
                            settings=settings)
                    output = sys.stdout.getvalue().strip()

                    for asserted_output in test_case[2]:
                        self.assertIn(asserted_output, output)
                finally:
                    sys.stdout.close()

        finally:
            sys.stdout = saved_stdout

if __name__ == '__main__':
    unittest.main()
