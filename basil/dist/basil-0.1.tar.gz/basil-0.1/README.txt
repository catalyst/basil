=====
Basil
=====

Basil follows best practice to create a new python project in the current
directory from a given template. Basil also supports removing projects and
performing additional actions that are specific to templates. 

Features
========

* Installs required packages and pip packages.
* Creates a new virtualenv with virtualenvwrapper, and installs pip packages in it.
* Creates a project directory.
* Sets up virtualenv environment variables.
* Creates a git repo for source control.
* Handles destroying projects.
* Allows templates to provide additional actions to be performed on projects.

Usage
=====

    See: 'basil -h'

Thanks also to
==============

Grant Paton-Simpson for help with design and architecture.
