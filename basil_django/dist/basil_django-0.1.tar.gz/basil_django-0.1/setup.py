from setuptools import setup, find_packages

packages = find_packages()
namespace_packages = packages[:]
for package in namespace_packages:
    if package.split('.')[-1] == 'tests':
        namespace_packages.remove(package)

setup(
      name='basil_django',
      version='0.1',
      author='Benjamin Denham',
      author_email='ben.denham@gmail.com',
      packages=packages,
      namespace_packages=namespace_packages,
      url='',
      license='LICENSE.txt',
      description='Basil template to create a basic django project.',
      long_description=open('README.txt').read(),
      install_requires=['basil'],
      )
